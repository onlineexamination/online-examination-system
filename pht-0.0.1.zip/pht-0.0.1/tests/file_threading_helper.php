<?php

[$one, $two, $three] = $_THREAD;

var_dump($one, $two, $three);
